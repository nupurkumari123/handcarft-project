import { Component } from '@angular/core';

@Component({
  selector: 'onlinecraft',
  templateUrl: './fashion.component.html',
  //styleUrls: ['./fashion.component.css']
})
export class FashionComponent {
  
 title:string = 'craft';
 
}