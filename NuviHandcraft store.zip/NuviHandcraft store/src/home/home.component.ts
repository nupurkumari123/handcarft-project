import { Component } from '@angular/core';

@Component({
  selector: 'onlinecraft',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  
 title:string = 'craft';
 imgHeight : number = 600;
 imgWidth : number = 800;
 
}
 