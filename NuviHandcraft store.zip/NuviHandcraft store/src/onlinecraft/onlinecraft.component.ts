import { Component } from '@angular/core';

@Component({
  selector: 'craft',
  templateUrl: './onlinecraft.component.html',
 // styleUrls: ['./app.component.css']
})
export class OnlinecraftComponent {

 title:string = 'craft';
//  imgWidth:number=400;
//  imgHeight:number=400;
    

}
