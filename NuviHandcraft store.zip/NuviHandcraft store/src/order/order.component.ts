import { Component } from '@angular/core';

@Component({
  selector: 'onlinecraft',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent {
  
 title:string = 'craft';
 
}
 