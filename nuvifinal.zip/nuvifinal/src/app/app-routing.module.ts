import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './../home/home.component';
import { FashionComponent } from './../fashion/fashion.component';
import { LoginComponent } from './../login/login.component';
import { OnlinecraftComponent } from './../onlinecraft/onlinecraft.component';
import { ErrorComponent } from './../error/error.component';
const routes: Routes = [

{path:'home',component:HomeComponent},
{path:'fashion',component:FashionComponent},
{path:'login',component:LoginComponent},
//{path:'order',component:OrderComponent},
{path:'',component:OnlinecraftComponent},
{path:'**',component: ErrorComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
